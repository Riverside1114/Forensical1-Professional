# Forensical 1 Professional v3.1 - Installation Guide

## 🚀 Quick Installation

### Method 1: Download and Run (Recommended)
1. **Download:** Get `Forensical1-Professional-v3.1.zip` from [Releases](https://github.com/Riverside1114/Forensical1-Professional/releases)
2. **Extract:** Unzip to your desired location (e.g., `C:\Forensical1`)
3. **Launch:** Run `Launch_Forensical1_v3.1.bat` or `Forensical_1 Launcher.exe`

### Method 2: Quick Launch Scripts
Choose your preferred launch method:
- **`Launch_Forensical1_v3.1.bat`** - Full launcher with feature guide
- **`Quick_Launch.bat`** - Direct access to main GUI
- **`Shield_Control.bat`** - Protection system management

## 📁 Package Contents

```
Forensical1-Professional-v3.1/
├── Forensical_1 Launcher.exe          # Main launcher application
├── Forensical 1/                      # Application directory
│   ├── Forensical_1 Launcher.exe      # Launcher executable
│   ├── .core/                          # Hidden core files
│   │   ├── Forensical_1 Main.exe       # Main application
│   │   └── [ImGui libraries]           # UI components
│   ├── Add_AV_Exclusion.bat            # Antivirus exclusion helper
│   └── Reports/                        # Generated reports directory
├── Launch_Forensical1_v3.1.bat        # Enhanced launcher script
├── Quick_Launch.bat                   # Direct GUI launcher
├── Shield_Control.bat                 # Protection management
├── README.md                          # Documentation
├── RELEASE_NOTES_v3.1.md             # Version 3.1 features
└── INSTALLATION_GUIDE.md             # This file
```

## ⚙️ System Requirements

**Minimum Requirements:**
- Windows 10 (x64) or Windows 11
- 4GB RAM
- 500MB free disk space
- Internet connection (for updates)

**Recommended:**
- Windows 10/11 (x64)
- 8GB+ RAM (for memory analysis features)
- Administrator privileges
- SSD storage for optimal performance

## 🛡️ First-Time Setup

### 1. Run Initial Setup
```bash
# Run as Administrator (recommended)
Right-click Launch_Forensical1_v3.1.bat → "Run as administrator"
```

### 2. Configure Protection Shields
1. Launch Forensical 1 Professional
2. Navigate to **Protection** menu
3. Enable desired shields:
   - 🛡️ Ransomware Shield
   - ⌨️ Keylogger Shield  
   - 💰 Crypto Miner Shield

### 3. Test Advanced Features
- **Analysis** → 🧠 Advanced Memory Analysis
- **Analysis** → 🔍 Hidden Process Scanner
- **Protection** → 🗺️ Threat Map Visualization

## 🔧 Configuration Options

### Antivirus Exclusions
If your antivirus flags the application:
1. Run `Add_AV_Exclusion.bat` (as Administrator)
2. Or manually add exclusion for the Forensical 1 folder

### Performance Tuning
- **Memory Analysis:** Requires 8GB+ RAM for optimal performance
- **Real-time Shields:** Minimal CPU impact (~1-2%)
- **Background Service:** Ultra-low resource usage

## 🔄 Automatic Updates

The launcher includes automatic update checking:
- Updates checked via GitHub API
- Notifications appear in launcher
- Optional update installation
- Always backward compatible

## 🚨 Troubleshooting

### Application Won't Start
1. **Check Requirements:** Verify Windows 10/11 x64
2. **Run as Admin:** Right-click → "Run as administrator"
3. **Antivirus:** Add folder to exclusions
4. **Dependencies:** Install Visual C++ Redistributables if needed

### Protection Shields Not Working
1. **Admin Rights:** Shields require elevated privileges
2. **Antivirus:** Check for interference
3. **Compatibility:** Some security software may conflict

### Memory Analysis Issues
1. **RAM:** Ensure 8GB+ for large dumps
2. **Disk Space:** Dumps saved to Documents/ForensicalDumps
3. **Permissions:** Administrator rights required

## 💼 Professional Deployment

### Enterprise Installation
- Silent deployment via GPO
- Centralized configuration management
- Network-based update distribution
- Professional licensing options

### Forensic Lab Setup
- Dedicated forensic workstation
- Isolated network environment  
- Professional evidence management
- Integration with forensic workflows

## 📞 Support

### Documentation
- **Built-in Help:** Available in application
- **GitHub Wiki:** Comprehensive guides
- **Release Notes:** Feature documentation

### Issues & Bugs
- **GitHub Issues:** Bug reports and feature requests
- **Community:** Professional user forum
- **Professional Support:** Enterprise customers

### Professional Services
- **Training:** Digital forensics courses
- **Consulting:** Custom deployment
- **Integration:** Enterprise systems

---

## 🎯 Next Steps

After installation:
1. **Explore Features:** Try each analysis module
2. **Configure Shields:** Set up real-time protection
3. **Generate Reports:** Test PDF export functionality
4. **Professional Use:** Integrate into workflows

**Ready to begin professional digital forensics with Forensical 1 Professional v3.1!** 🔍🛡️💻
# 🛡️ ANTIVIRUS EXCLUSION GUIDE

## Why Forensic Tools Get Flagged

Forensical 1 Professional uses legitimate Windows APIs that are also commonly used by malware:

- **Process enumeration** (to analyze running processes)
- **Memory access** (for memory forensics)
- **Network monitoring** (for network analysis)
- **Registry access** (for registry forensics)
- **Disk access** (for disk forensics)

This is **completely normal** for legitimate forensic software and cybersecurity tools.

## 🔧 Adding Exclusions

### For Avast Antivirus:
1. Open **Avast Antivirus**
2. Go to **Settings** (gear icon)
3. Click **General** → **Exceptions**
4. Click **"Add Exception"**
5. Select the folder
6. Check **"Exclude from all shields"**
7. Click **"Add Exception"**

### For Windows Defender:
1. Open **Windows Security**
2. Go to **Virus & threat protection**
3. Click **"Manage settings"** under Virus & threat protection settings
4. Scroll down to **Exclusions**
5. Click **"Add or remove exclusions"**
6. Add folder exclusion for the folder

### For Norton Antivirus:
1. Open **Norton Security**
2. Click **Settings**
3. Go to **Antivirus** tab
4. Click **Scans and Risks**
5. Under **Exclusions/Low Risks**, click **Configure**
6. Click **Add** → **Folders**
7. Browse and select the folder
8. Click **OK**

### For McAfee:
1. Open **McAfee Total Protection**
2. Click **PC Security**
3. Click **Real-Time Scanning**
4. Click **Excluded Files**
5. Click **Add File** → **Add Folder**
6. Select the folder
7. Click **Add**

### For Kaspersky:
1. Open **Kaspersky**
2. Go to **Settings** (gear icon)
3. Click **Additional** → **Threats and Exclusions**
4. Click **Manage Exclusions**
5. Click **Add** → **Browse**
6. Select the folder
7. Check **Do not scan files**
8. Click **Add**

### For Bitdefender:
1. Open **Bitdefender**
2. Go to **Protection**
3. Click **Antivirus**
4. Click **Advanced** → **Exclusions**
5. Click **Add an Exception**
6. Select **File or Folder**
7. Browse and select the folder
8. Click **Save**

### For ESET NOD32:
1. Open **ESET Security**
2. Press **F5** for Advanced Settings
3. Go to **Computer** → **Antivirus**
4. Click **Exclusions**
5. Click **Add**
6. Browse and select the folder
7. Click **OK**

### For Trend Micro:
1. Open **Trend Micro Security**
2. Go to **Settings**
3. Click **Exception Lists**
4. Under **Folder/File Exception List**, click **Add**
5. Browse and select the folder
6. Click **OK**

### For Malwarebytes:
1. Open **Malwarebytes**
2. Go to **Settings** → **Exclusions**
3. Click **Add Exclusion**
4. Select **Exclude a folder**
5. Browse and select the folder
6. Click **Done**

### For AVG Antivirus:
1. Open **AVG Antivirus**
2. Go to **Settings** (gear icon)
3. Click **General** → **Exceptions**
4. Click **Add Exception**
5. Select **Folder**
6. Browse and select the folder
7. Click **Add Exception**

### For Windows Defender (Detailed):
1. Press **Win + I** → **Update & Security**
2. Click **Windows Security** → **Virus & threat protection**
3. Under **Virus & threat protection settings**, click **Manage settings**
4. Scroll to **Exclusions** → **Add or remove exclusions**
5. Click **Add an exclusion** → **Folder**
6. Browse and select the folder
7. Click **Select Folder**

### For Other Antiviruses:
- Look for **"Exclusions"**, **"Exceptions"**, **"Whitelist"**, or **"Trusted Files"** settings
- Add the entire folder to exclusions
- Exclude from **all protection modules** (real-time, behavior, web protection, etc.)
- Some antiviruses call it **"Quarantine Exclusions"** or **"Scan Exclusions"**

## 🏢 For Enterprise Users

If you're using this in a corporate environment:
- Contact your IT security team
- Explain this is legitimate forensic analysis software
- Provide this documentation
- Request exclusion through proper channels

## ✅ Verification

After adding exclusions:
1. Run `Add_AV_Exclusion.bat` to verify the path
2. The antivirus should no longer scan the Forensical 1 folder
3. You can now run the launcher without interruption

## 🔍 False Positive Reports

If your antivirus continues to flag the software:
- This is a **false positive**
- Forensical 1 is **open source** and safe
- You can verify the source code on GitHub
- Report the false positive to your antivirus vendor

---

**Forensical 1 Professional** - Legitimate Digital Forensics Suite